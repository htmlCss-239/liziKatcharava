const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('nav-menu');

hamburger.addEventListener('click', () => {
    navMenu.classList.toggle('show');
});

// Dropdown toggle
document.querySelectorAll('.nav-item.dropdown').forEach(drop => {
    drop.addEventListener('click', () => {
        drop.classList.toggle('active');
    });
});

// Sub dropdown
document.querySelectorAll('.dropdown-sub').forEach(sub => {
    sub.addEventListener('click', (e) => {
        e.stopPropagation();
        sub.classList.toggle('active');
    });
});
document.getElementById("hamburger").addEventListener("click", function () {
    document.getElementById("nav-menu").classList.toggle("show");
});

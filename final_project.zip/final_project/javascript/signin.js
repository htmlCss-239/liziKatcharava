const container = document.getElementById('container');

// Desktop toggle buttons (hidden in HTML toggle panels)
const registerBtn = document.getElementById('register'); 
const loginBtn = document.getElementById('login');       

if (registerBtn) {
  registerBtn.addEventListener('click', () => {
    container.classList.add("active");
  });
}

if (loginBtn) {
  loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
  });
}

// Mobile links inside forms
const showSignUp = document.getElementById('showSignUp');
const showSignIn = document.getElementById('showSignIn');

if (showSignUp) {
  showSignUp.addEventListener('click', (e) => {
    e.preventDefault();
    container.classList.add('active'); // Switch to Sign Up
  });
}

if (showSignIn) {
  showSignIn.addEventListener('click', (e) => {
    e.preventDefault();
    container.classList.remove('active'); // Switch to Sign In
  });
}
